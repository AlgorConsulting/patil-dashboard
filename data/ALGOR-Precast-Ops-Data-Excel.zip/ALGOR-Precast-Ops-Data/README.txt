Sleeper & Precast Plant Network — synthetic sample dataset (ALGOR Analytics)

All data is synthetic and generated for demonstration only. Amounts in Indian rupees (INR).
Period: Apr 2023 - Mar 2026 (Indian financial years). Data as of 31 Mar 2026.

Tables:
  sales_monthly: 4,662 rows
  prod_monthly: 1,386 rows
  down_monthly: 4,032 rows
  defects_monthly: 9,702 rows
  plant_monthly: 504 rows
  budget_monthly: 504 rows
  inv_monthly: 2,016 rows
  casting_log_sample: 7,200 rows
  inspection_lot_register: 11,963 rows
  dispatch_register_sample: 6,240 rows
  materials_monthly_position: 5,544 rows
